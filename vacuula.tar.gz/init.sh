#!/bin/sh
# from now on its: jesus take the wheel - no longer bound by what the neato terminal can do

# Exit on error
set -eux

# Trap errors and log failures
trap 'log "FAILED: Script error occurred"' ERR

# Create timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MARKER=/tmp/vacuula_init_started

log () {
    echo "[vacuula-init] $1" >> /emmc/vacuula-init.log
    echo "[vacuula-init] $1" > /dev/ser1
    # echo "[vacuula-init] $1" > /dev/serusb1 # should the installer try to read the logs?
}

# run once
set -C  # Enable noclobber - prevents overwriting files
# Try to create lock file atomically - only succeeds if it doesn't exist
if echo $$ > /tmp/vacuula_init_lock 2>/dev/null; then
    log "Acquired lock with PID $$"
    set +C  # Disable noclobber
else
    log "Lock already held, exiting"
    set +C  # Disable noclobber
    exit 0
fi

if [ -d /emmc/vacuula ]; then
    log "vacuula directory already exists, skipping creation" # todo for updates in the future
else
    log "Starting vacuula initialization, creating directory"
    mkdir -p /emmc/vacuula

    log "Extracting files to /emmc/vacuula"
    tar xzf /tmp/upload -C /emmc/vacuula

    log "chmod script"
    chmod +x /emmc/vacuula/vacuula.sh

    log "checking extract"
    log "$(ls -lah /emmc/vacuula)"

    log "current configuration:"
    log "$(qdbc -d /dev/qdb/systemdb "SELECT * FROM StringSettings")"
    log "$(qdbc -d /dev/qdb/systemdb "SELECT * FROM IntegerSettings")"

    log "Setting UTCOFFSET to execute vacuula on boot"
    qdbc -d /dev/qdb/systemdb "INSERT OR REPLACE INTO StringSettings( Name, Value ) VALUES ( 'UTCOFFSET', 'STD-0:00DST-0:00;{ /emmc/vacuula/vacuula.sh start_mod &}' );" || true
    NEW_VALUE=$(qdbc -f data -d /dev/qdb/systemdb "SELECT Value FROM StringSettings WHERE Name='UTCOFFSET';")
    if [ "$NEW_VALUE" != "STD-0:00DST-0:00;{ /emmc/vacuula/vacuula.sh start_mod &}" ]; then
        log "Failed to set UTCOFFSET, got: $NEW_VALUE"
        exit 1
    else
        log "UTCOFFSET set successfully to: $NEW_VALUE"
    fi

    # set this so that robot will try to relink and register with beehive on next boot
    log "Setting BEEHIVELINKED to 1"
    qdbc -d /dev/qdb/systemdb "INSERT OR REPLACE INTO IntegerSettings( Name, Value ) VALUES ( 'BEEHIVELINKED', 1 );" || true
    NEW_VALUE=$(qdbc -f data -d /dev/qdb/systemdb "SELECT Value FROM IntegerSettings WHERE Name='BEEHIVELINKED';")
    if [ "$NEW_VALUE" != "1" ]; then
        log "Failed to set BEEHIVELINKED, got: $NEW_VALUE"
        exit 1
    else
        log "BEEHIVELINKED set successfully to: $NEW_VALUE"
    fi

    # turn access point off
    log "Setting APDESIRED to 0"
    qdbc -d /dev/qdb/systemdb "INSERT OR REPLACE INTO IntegerSettings( Name, Value ) VALUES ( 'APDESIRED', 0 );" || true
    NEW_VALUE=$(qdbc -f data -d /dev/qdb/systemdb "SELECT Value FROM IntegerSettings WHERE Name='APDESIRED';")
    if [ "$NEW_VALUE" != "0" ]; then
        log "Failed to set APDESIRED, got: $NEW_VALUE"
        exit 1
    else
        log "APDESIRED set successfully to: $NEW_VALUE"
    fi

    log "check config after update:"
    log "$(qdbc -d /dev/qdb/systemdb "SELECT * FROM StringSettings")"
    log "$(qdbc -d /dev/qdb/systemdb "SELECT * FROM IntegerSettings")"

    log "make the mod"
    /emmc/vacuula/vacuula.sh make_mod

    # check if keys exist and delete them to force regeneration
    if [ -f /emmc/keys/robot_keys/robot_rsa ]; then
        log "delete recently genereted keys to they get regenerated"
        rm /emmc/keys/robot_keys/robot_rsa
        rm /emmc/keys/robot_keys/robot_rsa.pub.pem
        log "keys deleted, they should be regenerated on next boot"
    else
        log "No existing keys found, skipping deletion"
    fi

    log "Initialization complete"
    log "Rebooting..."
    sync
    shutdown
fi